
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');

const app = express();

app.use(express.json());
app.use(cors());

const db = new sqlite3.Database('../db/termine.db', (err) => {
	if (err) {
		console.error("Fehler DB:", err.message);
	} else {
		console.log("Datenbank verbunden.");
	}
});

app.get('/', (req, res) => {
	res.send("Backend API läuft");
});

app.get('/api/termine', (req, res) => {
	db.all("SELECT * FROM termine ORDER BY datum ASC, zeit ASC", (err, rows) => {
		if (err) {
			return res.status(500).json({error: err.message});
		}
		res.json(rows);
	});
});
	
app.get('/api/termine/:datum', (req, res) => {
	const datum = req.params.datum;
	db.all("SELECT zeit FROM termine WHERE datum = ?", [datum], (err, rows) => {
		if (err) {
			return res.status(500).json({error: err.message});
		}
		res.json(rows);
	});
});

app.post('/api/termine', (req, res) => {
	const {datum, zeit} = req.body;
	db.run("INSERT INTO termine (datum, zeit) VALUES (?, ?)",
		[datum, zeit],
		function(err) {
			if (err) {
				return res.status(500).json({success: false, error: err.message});
			}
			res.json({success: true, id: this.lastID});
		}
	);
});

app.post('/api/buchen', (req, res) => {
		const {datum, zeit, name, email} = req.body;
		console.log('Buchung erhalten:', {datum, zeit, name, email, telefon});
		
		db.run("INSERT INTO termine (datum, zeit, name, email, telefon) VALUES (?, ?, ?, ?, ?)",
			[datum, zeit, name, email, telefon],
			function(err) {
				if (err) {
					console.error("DB Fehler:", err.message);
					return res.json({success: false, error: err,message});
				}
				console.log("Termin gespeichert, ID:", this.lastID);
				res.json({success: true});
			}
		);
});

app.listen(4000, () => {
	console.log("Backend API läuft auf http://localhost:4000");
});